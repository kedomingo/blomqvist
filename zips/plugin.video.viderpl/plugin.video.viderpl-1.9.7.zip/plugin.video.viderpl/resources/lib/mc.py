# -*- coding: utf-8 -*-
import os,re
import xbmc,xbmcaddon,xbmcgui,xbmcvfs

addonInfo     = xbmcaddon.Addon().getAddonInfo
file_open     = xbmcvfs.File
file_delete   = xbmcvfs.delete
try:
    DATAPATH      = xbmc.translatePath(addonInfo('profile')).decode('utf-8')
except:
    DATAPATH      = xbmc.translatePath(addonInfo('profile'))#.decode('utf-8')
control       = xbmcgui.ControlImage
dialog        = xbmcgui.WindowDialog()
KEYBOARD      = xbmc.Keyboard


def keyboard(response):
    try:
        i = os.path.join(DATAPATH,'captcha')
        f = file_open(i, 'w')
        f.write(response)
        f.close()
        f = control(450,15,375,115, i)
        d = dialog
        d.addControl(f)
        file_delete(i)
        d.show()
        k = xbmc.Keyboard('','')
        k.doModal()
        c = k.getText() if k.isConfirmed() else None
        if c == '': c = None
        d.removeControl(f)
        d.close()

        return c.upper()
    except:
        return

def getDialog(title='',text='',action=''):
    xbmcgui.Dialog().ok(title,text,action)
