# coding: UTF-8
import ast
import sys, re

import requests
import routing
import xbmcvfs

from .helper import Helper
from datetime import datetime, timedelta

base_url = sys.argv[0]
handle = int(sys.argv[1])
helper = Helper(base_url, handle)
plugin = routing.Plugin()

try:
    # Python 3
    from urllib.parse import quote_plus, unquote_plus, quote, unquote
except:
    # Python 2.7
    from urllib import quote_plus, unquote_plus, quote, unquote

	
def createConfig():
	if not helper.get_setting('deviceid'):
		json_data = {
			'appVersion': '2.6.55',
			'displayName': None,
			'model': 'Firefox',
			'manufacturer': 'Mozilla',
			'osName': 'Windows',
			'osVersion': '69',
			'platform': 'Firefox',
			'platformVersion': '115.0',
			'architecture': 'unknown',
			'profile': 'WEB',
			'store': 'CHILI',
			'screenWidth': 1366,
			'screenHeight': 768,
		}
		
		jsdata = helper.request_sess('https://www.plus.fifa.com/gatekeeper/api/v1/devices/', 'post', headers=helper.headers1, data = json_data, json=True, json_data = True)

		devid = jsdata.get("id", None)
	
		helper.set_setting('deviceid', str(devid))
	acv=helper.headers


	jsdata = helper.request_sess(helper.configs, 'get', headers=helper.headers, json=True)
	mainMenuIdWebsite = jsdata.get('mainMenuIdWebsite', None)
	return helper.case_url.format('showcases',mainMenuIdWebsite)
	
@plugin.route('/')
def root():
	topmenu=createConfig()

	jsdata = helper.request_sess(topmenu, 'get', headers=helper.headers, json=True)
	

	for tt in jsdata:
		title = tt.get("title", None) 
		if title == 'News' or  'Match Centre' in title or  title == 'FIFA.com' or 'Home' in title:
			continue
		url = tt.get("callToAction", None).get("redirectId", None)
	
		entryType = tt.get("callToAction", None).get("redirectType", None)
		if 'showcase' in entryType.lower():
			entryType = 'showcases'

		mod = plugin.url_for(listsubmenu, url_entryType=quote_plus(url+'|'+entryType))
		if 'live' in title.lower():

			mod = plugin.url_for(listcontent,  url = quote_plus(url+'|'+entryType))
		helper.add_item(title, mod)

	helper.eod()


@plugin.route('/listsubmenu/<url_entryType>')

def listsubmenu(url_entryType):
	url_entryType=unquote_plus(url_entryType)
	dod,entryType = url_entryType.split('|')
	if 'page' == entryType:
		x= 'pages'

	page= helper.case_url.format(entryType,dod)
	
	
	
	jsdata = helper.request_sess(page, 'get', headers=helper.headers, json=True)
	for x in jsdata:
		if 'banner' in x.get('showcaseType').lower():
			continue
		jpg = ''
		if 'wideCoverUrl' in x:
			jpg = x.get('wideCoverUrl', None)
		title = x.get('title', None)	
		description = x.get('description', None)	
		
		info = {
			'title': title,
			'plot': description
		}
		
		art = {
			'icon': jpg,
			'fanart': helper.addon.getAddonInfo('fanart'),
		}

		entryEndpoint = x.get('catalogRedirectId')
		catalogRedirectType = x.get('catalogRedirectType')

		if 'showcase' in catalogRedirectType.lower():
			catalogRedirectType = 'showcases'
		
		dod = plugin.url_for(listcontent,  url = quote_plus(entryEndpoint+'|'+catalogRedirectType))
	

		helper.add_item(title, dod , info=info, art=art) 
	helper.eod()
    
@plugin.route('/listcujoo/<url>')
def listcujoo(url):

    url = unquote_plus(url)
    mainurl = url
    if 'maOttCalenda' in url:
        ListCalendar()
    else:
    
        if not 'mcls-api.mycujoo' in url:
    
            from datetime import datetime, timedelta
            now = datetime.now()+timedelta(hours=-4)
            czas=now.strftime('%Y-%m-%dT%H:%M:%S.000Z')
    
            url = 'https://mcls-api.mycujoo.tv/bff/events/v1beta1?order_by=ORDER_START_TIME_ASC&page_size=45&start_after_time='+czas+'&status=EVENT_STATUS_STARTED'

        jsdata = helper.request_sess(url, 'get', headers=helper.headersCujoo, json=True)

        events = jsdata.get('events', None)
        for event in events:

            id = event.get('id', None)
            title = event.get('title', None)
            description = event.get('description', None)
            thumbnail_url = event.get('thumbnail_url', None)
            competition_name = event.get('metadata', None).get('competition_name', None)

            if not thumbnail_url:

                thumbnail_url = helper.addon.getAddonInfo('icon')

            if event.get('status' , None) == 'EVENT_STATUS_FINISHED':
                metadata = event.get('metadata', None)

                try:
                    gosp = metadata.get('home_team', None).get('score', None)
                    gosc = metadata.get('away_team', None).get('score', None)

                    title = title.replace(' vs ', ' [COLOR gold][B]('+str(gosp)+':'+str(gosc)+')[/B][/COLOR] ')
                    description+='[CR][COLOR gold][B]('+str(gosp)+':'+str(gosc)+')[/B][/COLOR] '
                except:
                    title=title
            elif event.get('status' , None) == 'EVENT_STATUS_SCHEDULED':
                start_time = event.get('start_time', None)

                cortime = helper.getCorrectTime(start_time)
                title = '[COLOR yellow][B]'+cortime+'[/B][/COLOR] '+title
                description+='[CR][COLOR yellow][B]'+cortime+'[/B][/COLOR] '

            elif event.get('status' , None) == 'EVENT_STATUS_STARTED':
                
                title = '[COLOR lightgreen][B]LIVE [/B][/COLOR] '+title
            mod = plugin.url_for(playcujoo, id=id)
            if competition_name:
                title+='  [COLOR khaki]('+competition_name+')[/COLOR]'
            ispla = True
            info = {
                'title': title,
                'plot': description
            }
        
            art = {
                'icon': thumbnail_url,
                'fanart': helper.addon.getAddonInfo('fanart'),
            }
    
            helper.add_item(title, mod, playable=ispla, info=info, art=art)    
    helper.eod()


    
    
def ListCalendar():    
    
    days = helper.CreateDays()
    for d in days:
        url = 'https://mcls-api.mycujoo.tv/bff/events/v1beta1?order_by=ORDER_START_TIME_ASC&page_size=65'+d.get('dodane', None)
        mod = plugin.url_for(listcujoo,  url = quote_plus(url))
        ispla = False
        info = {
            'title': d.get('dzien', None),

        }
        
        art = {}
        
        helper.add_item(d.get('dzien', None), mod, playable=ispla, info=info, art=art)    

    return    
    
    
    
@plugin.route('/playcujoo/<id>')
def playcujoo(id):

    stream=''
    url ='https://mls-api.mycujoo.tv/bff/events/v1beta1/'+id
    jsdata = helper.request_sess(url, 'get', headers=helper.headersCujoo, json=True)
    error = jsdata.get('streams', None)[0].get('error', None)
    if error:
        message = error.get("message", None)
        if 'geoblocked' in message:
            streams = jsdata.get('metadata', None).get("mcls_internal_data", None)
            for st in streams:
                if st.get('name', None) =='video_url':
                    stream = st.get('value', None)
                    break
    else:
        stream = jsdata.get('streams', None)[0].get('full_url', None)
        if not stream:
            streams = jsdata.get('metadata', None).get("mcls_internal_data", None)
            for st in streams:
                if st.get('name', None) =='video_url':
                    stream = st.get('value', None)
                    break
    if stream:                
        helper.PlayVid(stream, PROTOCOL = 'hls')
    
@plugin.route('/listcontent/<url>')
def listcontent(url):

	url_entryType = unquote_plus(url)
	dod,entryType = url_entryType.split('|')
	page= helper.case_url.format(entryType,dod)+'?orderBy=EDITORIAL'
	jsdata = helper.request_sess(page, 'get', headers=helper.headers, json=True)
	for item in jsdata:
		title = item.get('title', None)
		catalogRedirectId = item.get('catalogRedirectId', None)
		jpg = item.get('coverUrl', None)
		tt = item.get('type', None)
		if not jpg:
			jpg = item.get('wideCoverUrl', None)
		catalogRedirectType = item.get('catalogRedirectType', None)
		if 'movie' in catalogRedirectType.lower() or 'simple' in catalogRedirectType.lower() or 'event' in catalogRedirectType.lower():
			catalogRedirectType = 'contents'
			entryId = catalogRedirectId+'|videoDetails'
			ispla = True
			mod = plugin.url_for(playvid, eidetyp=catalogRedirectId)
		elif 'series' in catalogRedirectType.lower():
			catalogRedirectType = 'contents'
			entryId = catalogRedirectId#+'|videoDetails'
			ispla = False
			mod = plugin.url_for(listseries, entryId=quote_plus(entryId+'|'+catalogRedirectType))
		if tt:

			
			if 'event' in tt.lower():
				start_time = item.get('contentStartDate', None)
				cortime = helper.getCorrectTime(start_time)
				title = title +' ('+cortime+')'
		info = {
			'title': title,
		}
	
		art = {
			'icon': jpg,
			'fanart': helper.addon.getAddonInfo('fanart'),
		}
	
		helper.add_item(title, mod, playable=ispla, info=info, art=art)  
 
	if mod:
		helper.eod()

@plugin.route('/listseries/<entryId>')
def listseries(entryId):
	url_entryType = unquote_plus(entryId)
	dod,entryType = url_entryType.split('|')


	page= helper.case_url.format(entryType,dod)
	jsdata = helper.request_sess(page, 'get', headers=helper.headers, json=True)
	for seas in jsdata:
		cv=''
		subtitle = seas.get('subtitle', None)

		entryid = seas.get('catalogRedirectId', None)
		jpg = seas.get('coverUrl', None)
		title = seas.get('title', None)
		tyt = title + ' ('+subtitle+')'
		mod = plugin.url_for(listEpisodes2, exlink=entryid)
		ispla = False
		info = {
			'title': tyt,
		}
	
		art = {
			'icon': jpg,
			'fanart': helper.addon.getAddonInfo('fanart'),
		}
		helper.add_item(tyt, mod, playable=ispla, info=info, art=art)  
	
	

	helper.eod()

@plugin.route('/listEpisodes2/<exlink>')
def listEpisodes2(exlink):


	page= helper.case_url.format('contents',exlink)
	jsdata = helper.request_sess(page, 'get', headers=helper.headers, json=True)

	for epis in jsdata:
		entry_id = epis.get('id', None)
		title = epis.get('title', None)
		jpg = epis.get('coverUrl', None)
		duration = epis.get('duration', None)
		try:
			dur = int(duration)/1000
		except:
			dur = 0
		yr = epis.get('productionYear', None)
		ispla = True
		mod = plugin.url_for(playvid, eidetyp=entry_id)
		info = {
			'title': title,
			'plot': title,
			#'season' : f.get('season'),
			'year':yr,
			'duration':dur
		}
	
		art = {
			'icon': jpg,
			'fanart': helper.addon.getAddonInfo('fanart'),
		}
	
		helper.add_item(title, mod, playable=ispla, info=info, art=art) 

	helper.eod()

def splitToSeasons(input):
    out={}
    seasons = [x.get('season') for x in input]
    for s in set(seasons):
        out['Season %02d'%s]=[input[i] for i, j in enumerate(seasons) if j == s]
    return out

def createSubtitle(url):
    m3u8 = helper.request_sess(url, 'get', headers=helper.headers, json=False)
    xx=re.findall('"subs",NAME="([^"]+)".*?URI="([^"]+)",LANGUAGE="([^"]+)"',m3u8,re.DOTALL)
    subsout = []
    for nm,uri,nm2 in xx:
        label =nm+' ['+nm2+']'
        subsout.append({'label':label,'subt':nm})
    if subsout:
        
        labels = [x.get('label') for x in subsout]
        sel = helper.dialog_select('Select subtitle:', labels)
        if sel > -1:
            subt=subsout[sel].get('subt')

            helper.set_setting('napis',subt)

    return 
@plugin.route('/playvid/<eidetyp>')
def playvid(eidetyp):

	if '|' in eidetyp:
		entryId,entryType = eidetyp.split('|')
	else:
		entryId = eidetyp
	
		
	url='https://www.plus.fifa.com/flux-capacitor/api/v1/videoasset?catalog='+entryId

	jsdata = helper.request_sess(url, 'get', headers=helper.headers, json=True)

	try:
		id_ = jsdata[0].get('id', None)
	except:
		id_ = None
	if id_:
		json_data = '{videoAssetId:'+id_+',autoPlay:false}'
		json_data ={"videoAssetId":id_,"autoPlay":False}
	
		
		
		jsdata = helper.request_sess('https://www.plus.fifa.com/flux-capacitor/api/v1/streaming/session', 'post', headers=helper.headersvid, data = json_data, json=True, json_data = True)
		id_ = jsdata.get('id', None)
		
		helper.headersvid.update({'x-chili-streaming-session': id_})
		widev = 'https://www.plus.fifa.com/flux-capacitor/api/v1/licensing/widevine/modular?sessionId='+id_
		jsdata = helper.request_sess('https://www.plus.fifa.com/flux-capacitor/api/v1/streaming/urls', 'get', headers=helper.headersvid, json=True)
		mpdurl = jsdata[0].get('url', None)
		
		
		lic_url =  widev+"|Content-Type=application/octet-stream|R{SSM}|"
		DRM = 'com.widevine.alpha'
		PROTOCOL = 'mpd'
			
		helper.PlayVid(mpdurl, lic_url, PROTOCOL, DRM, flags=False, subs = False)
	else:
		helper.notification('Error', "Can't play this stream\nTry again later.")
#	playURL = jsdata.get('playURL', None)
#	mpdurl = playURL
#	napisy = True
#	
#	mpdurl +='|User-Agent='    + quote('Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0')
#	
#	stream ='http://127.0.0.1:%s/dd='%(str(helper.proxyport))+mpdurl
#	helper.PlayVid(stream, lic_url='', PROTOCOL='hls', DRM='', certificate = '')


class Fifa(Helper):
    def __init__(self):
        super().__init__()
        plugin.run()


