# -*- coding: utf-8 -*-
import six,xbmc
from six.moves import urllib_request, urllib_parse

import json
import re
import requests
TIMEOUT = 10
UA	  = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'

def getUrl(url,data=None,cookies=None,ref=None):
	req = urllib_request.Request(url,data)
	req.add_header('User-Agent', UA)
	if cookies:
		req.add_header("Cookie", cookies)
	elif ref:
		req.add_header("Referer", ref)
	try:
		response = urllib_request.urlopen(req,timeout=TIMEOUT)
		link = response.read()
		response.close()
	except:
		link=''
	if six.PY3:
		link= link.decode(encoding='utf-8', errors='strict')
	return link

def getContent(url='',category='latest_highlights',page='1',**kwargs):
	return parseContent(category,page)

def parseContent(category='10', page=1):

	if '!' in str(page):
		lst, st_ti, pg = (str(page)).split('!')
	else:
		st_ti='' 
		lst=''
		pg = '1'

	url = 'https://api.meczyki.pl/api/v2/soccer/matches?limit=32&order%5BstartTime%5D=desc&highlight.category.id={}&startTime%5Bbefore%5D={}&order%5Bid%5D=desc&id%5Bgt%5D={}'.format(category,st_ti,lst)

	content = getUrl(url)
	out=[]
	content = content.decode('utf-8') if six.PY2 else content
	data = json.loads(content)

	wc = data.get('data',None)
	data =''
	content = ''



	for ij in wc:

		th = ij.get('homeParticipant',None).get('displayName',None)
		ta = ij.get('awayParticipant',None).get('displayName',None)
		sh = ij.get('homeScore',None)
		sa = ij.get('awayScore',None)
		startTime = ij.get('startTime',None)
		st_time = startTime.split('T')[0]
		tit = '[COLOR blue]{0} - {1}[/COLOR] ([B]{2}:{3}[/B])'.format(th,ta,sh,sa)

		compx = ij.get('competition', None).get('displayShortName',None)
		idx = ij.get('id')
		urln = 'https://api.meczyki.pl/api/v2/soccer/matches/'+str(idx)+'/highlights'
		out.append(
			{'title': tit,
			'url':urln,
			'code': '[COLOR khaki]%s[/COLOR], %s'%(compx,st_time)
			})
	startTime = startTime.split('+')[0].replace('T','+')#.split(
	ntp = str(idx)+'!'+startTime+'!'+str(int(pg)+1)
	nextPage = {'category': category, 'page': str(ntp) } if len(out) > 5 else False
	page = '!!1'  if int(pg)== 2 else page
	prevPage = {'category': category, 'page': str(page) } if st_ti  else False
	
	return out,(prevPage,nextPage)
def getStreamlet(url):
	html= getUrl(url).replace("\'",'"')
	src = re.compile('hls:"(//.*?)"').findall(html)[0]	
	src = 'http:'+src if src.startswith('//') else src
	return src
def getVideos(url):

	content = getUrl(url)
	v=[]
	content=content.replace("\'",'"')
	data = json.loads(content)
	vids = data.get('data', None).get('videos', None)
	for (i,vid) in enumerate (vids):
		acv=''
		typ = vid.get('type', None)
		linkId = vid.get('type', None)
		title  = vid.get('title', None)
		linkId = vid.get('linkId', None)
		src=''
		tt='twitt'
		if 'youtube' in typ:
			src = 'plugin://plugin.video.youtube/?action=play_video&videoid='+linkId
			
			tt= 'yt'
		elif 'twitt' in typ:
			tt= 'twitter' 
			src = 'https://x.com/i/status/'+linkId
		#	src = 'https://platform.twitter.com/embed/Tweet.html?dnt=false&embedId=twitter-widget-0&features=eyJ0ZndfdGltZWxpbmVfbGlzdCI6eyJidWNrZXQiOltdLCJ2ZXJzaW9uIjpudWxsfSwidGZ3X2ZvbGxvd2VyX2NvdW50X3N1bnNldCI6eyJidWNrZXQiOnRydWUsInZlcnNpb24iOm51bGx9LCJ0ZndfdHdlZXRfZWRpdF9iYWNrZW5kIjp7ImJ1Y2tldCI6Im9uIiwidmVyc2lvbiI6bnVsbH0sInRmd19yZWZzcmNfc2Vzc2lvbiI6eyJidWNrZXQiOiJvbiIsInZlcnNpb24iOm51bGx9LCJ0ZndfZm9zbnJfc29mdF9pbnRlcnZlbnRpb25zX2VuYWJsZWQiOnsiYnVja2V0Ijoib24iLCJ2ZXJzaW9uIjpudWxsfSwidGZ3X21peGVkX21lZGlhXzE1ODk3Ijp7ImJ1Y2tldCI6InRyZWF0bWVudCIsInZlcnNpb24iOm51bGx9LCJ0ZndfZXhwZXJpbWVudHNfY29va2llX2V4cGlyYXRpb24iOnsiYnVja2V0IjoxMjA5NjAwLCJ2ZXJzaW9uIjpudWxsfSwidGZ3X3Nob3dfYmlyZHdhdGNoX3Bpdm90c19lbmFibGVkIjp7ImJ1Y2tldCI6Im9uIiwidmVyc2lvbiI6bnVsbH0sInRmd19kdXBsaWNhdGVfc2NyaWJlc190b19zZXR0aW5ncyI6eyJidWNrZXQiOiJvbiIsInZlcnNpb24iOm51bGx9LCJ0ZndfdXNlX3Byb2ZpbGVfaW1hZ2Vfc2hhcGVfZW5hYmxlZCI6eyJidWNrZXQiOiJvbiIsInZlcnNpb24iOm51bGx9LCJ0ZndfdmlkZW9faGxzX2R5bmFtaWNfbWFuaWZlc3RzXzE1MDgyIjp7ImJ1Y2tldCI6InRydWVfYml0cmF0ZSIsInZlcnNpb24iOm51bGx9LCJ0ZndfbGVnYWN5X3RpbWVsaW5lX3N1bnNldCI6eyJidWNrZXQiOnRydWUsInZlcnNpb24iOm51bGx9LCJ0ZndfdHdlZXRfZWRpdF9mcm9udGVuZCI6eyJidWNrZXQiOiJvbiIsInZlcnNpb24iOm51bGx9fQ==&frame=false&hideCard=false&hideThread=false&id='+linkId#1769465325865640377		#src = rAxsvNL-zMk

		i=i+1
		v.append({'title':title+' - link %s - %s'%(i,tt),'url':src})
	if not v:
		v={'msg':'Brak linku lub przekierowanie na inna strone.'}

	return v

	
def resolveTwitter(url):
	zz=''
	sess=requests.Session()
	headers = {
		'Host': 'ssstwitter.com',

		'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
		'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'dnt': '1',
		'upgrade-insecure-requests': '1',
		'sec-fetch-dest': 'document',
		'sec-fetch-mode': 'navigate',
		'sec-fetch-site': 'none',
		'sec-fetch-user': '?1',

	}

	response = sess.get('https://ssstwitter.com/en', headers=headers, verify=False).text
	include = re.findall('data\-hx\-post(.*?)form',response, re.DOTALL+re.I)[0]
	print(include)
	tt= re.findall("tt\s*\:\s*'([^']+)'",include,re.DOTALL)[0]
	ts= re.findall("ts\s*\:\s*(.+?),",include,re.DOTALL)[0]
	headers = {
		'Host': 'ssstwitter.com',

		'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
		'accept': '*/*',
		'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
		'hx-request': 'true',
		'hx-target': 'target',
		'hx-current-url': 'https://ssstwitter.com/en',
		'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
		'origin': 'https://ssstwitter.com',
		'dnt': '1',
		'referer': 'https://ssstwitter.com/en',
		'sec-fetch-dest': 'empty',
		'sec-fetch-mode': 'cors',
		'sec-fetch-site': 'same-origin',

	}
	
	data = {
		'id': url,
		'locale': 'en',
		'tt': tt,
		'ts': ts,
		'source': 'form',
	}
	
	response = sess.post('https://ssstwitter.com/', headers=headers, data=data).text
	result = re.findall('Download\s*video(.*?)indicator',response,re.DOTALL+re.I)[0]
	href = re.findall('href\s*=\s*"([^"]+)"',result,re.DOTALL)[-1]
	return href

	
def getMain():

	content = getUrl('https://www.meczyki.pl/mecze')

	cat = re.findall('<div class="section-item"\s*data.*?><a href="([^"]+).+?><img src="([^"]+)"\s*alt="([^"]+)"',content,re.DOTALL)
	
	out=[{'title':'Najnowsze Skróty','url':'','img':'meczykipl','params':{'category':0,'page':1}}]
	for category,img,title in cat:
		if 'http' in img:

			if title:
				img=(title.strip()).lower()
				if 'liga' in img:
					img='liga'
				elif 'dzynarodowe' in img:
					img ='fifa'
				elif 'inne' in img:
					img ='meczykipl'	
				category = re.findall('\w+\/(\d+)\/',category)[0]
				out.append({'title':title.strip(),'url':'','img':img,'params':{'category':category,'page':1}})
	return out

def getEkstrOrg(link):
	content = getUrl(link)
	src = re.compile('iframe.*src="(.+?)"').findall(content)#[0]	
	src = src[0] if src else ''
	
	if src:
		content = getUrl(src+'/config',ref=link)
		data = json.loads(content)	
		src = data['request']['files']['hls']['cdns']['fastly_skyfire']['url']

	return src
def getMatchat(link):
	content = getUrl(link)
	content=content.replace("\'",'"')
	m3u8=re.findall('hls\:|source\:"(.+?)"',content,re.DOTALL)[0]
	str='https:'+m3u8
	return str
	
def getUpclips(link):
	content = getUrl(link)
	content=content.replace("\'",'"')

	if 'Video Removed' in content:
		return ''
	try:
		m3u8=re.findall("""hlsSource\:|source\:['"](.+?)['"]""",content,re.DOTALL)[0]
	except:
		m3u8=re.findall("""src:\s*['"](.+?)['"].+?type:\s*['"]application""",content,re.DOTALL)#[0]#src: "
		if m3u8:
			m3u8=m3u8[0]
		else:
			m3u8=re.findall("""hls\:['"](.+?)['"]""",content,re.DOTALL)[0]

	if m3u8.startswith('//'): m3u8 = 'https:' + m3u8
	#str='https:'+m3u8
	return m3u8
	
def getAliezme(link):
	content = getUrl(link)
	content=content.replace("\'",'"').replace('&quot;','"')

	next_url = re.compile('src="(.+?)"\s*width\=').findall(content)

	url2 = next_url[0]
	url2 = 'https:'+url2 if url2.startswith('//') else url2
	content = getUrl(url2)
	content=content.replace("\'",'"')

	ff=re.findall('file:\s+"(.+?)"',content,re.DOTALL)
	str_url=''

	if ff:
		ff=ff[0]
		if ',' in ff:
			str_url = ff.split(',')[0]
		else:
			str_url = ff
	str_url = 'https:'+str_url if str_url.startswith('//') else str_url
	return	str_url 
